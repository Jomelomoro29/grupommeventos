import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.53.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AuthRequest {
  username: string;
  password: string;
  action: 'login' | 'register';
  displayName?: string;
}

// Simple password hashing function using Web Crypto API
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'simple_salt_2024');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { username, password, action, displayName }: AuthRequest = await req.json();

    if (!username || !password) {
      return new Response(
        JSON.stringify({ error: 'Username and password are required' }),
        {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        }
      );
    }

    if (action === 'register') {
      // Check if username is available
      const { data: isAvailable, error: checkError } = await supabase.rpc('check_username_available', {
        p_username: username
      });

      if (checkError) {
        console.error('Username check error:', checkError);
        return new Response(
          JSON.stringify({ error: 'Error checking username availability' }),
          {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      if (!isAvailable) {
        return new Response(
          JSON.stringify({ error: 'Username already exists' }),
          {
            status: 400,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      // Hash the password
      const hashedPassword = await hashPassword(password);

      // Create the user in our custom table
      const { data: userData, error: createError } = await supabase
        .from('custom_users')
        .insert({
          username: username,
          password_hash: hashedPassword,
          display_name: displayName || username
        })
        .select()
        .single();

      if (createError) {
        console.error('User creation error:', createError);
        return new Response(
          JSON.stringify({ error: 'Failed to create user' }),
          {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'User registered successfully',
          userId: userData.id 
        }),
        {
          status: 201,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        }
      );

    } else if (action === 'login') {
      // Get user by username
      const { data, error } = await supabase.rpc('get_user_by_username', {
        p_username: username
      });

      if (error) {
        console.error('User lookup error:', error);
        return new Response(
          JSON.stringify({ error: 'Authentication failed' }),
          {
            status: 401,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      if (!data || data.length === 0) {
        return new Response(
          JSON.stringify({ error: 'Invalid username or password' }),
          {
            status: 401,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      const user = data[0];
      
      // Hash the provided password and compare
      const hashedPassword = await hashPassword(password);
      
      if (hashedPassword !== user.password_hash) {
        return new Response(
          JSON.stringify({ error: 'Invalid username or password' }),
          {
            status: 401,
            headers: { 'Content-Type': 'application/json', ...corsHeaders },
          }
        );
      }

      // Create a session token
      const sessionToken = btoa(JSON.stringify({
        userId: user.id,
        username: user.username,
        displayName: user.display_name,
        timestamp: Date.now()
      }));

      return new Response(
        JSON.stringify({
          success: true,
          user: {
            id: user.id,
            username: user.username,
            email: `${user.username}@local`, // Fake email for compatibility
            name: user.display_name || user.username,
            role: 'user'
          },
          sessionToken
        }),
        {
          status: 200,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        }
      );
    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid action' }),
        {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        }
      );
    }

  } catch (error: any) {
    console.error('Error in username-auth function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      }
    );
  }
};

serve(handler);