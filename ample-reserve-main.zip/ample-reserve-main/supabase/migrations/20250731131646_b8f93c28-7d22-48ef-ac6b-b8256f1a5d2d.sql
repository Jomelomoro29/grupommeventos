-- Create a custom users table for username/password authentication
CREATE TABLE IF NOT EXISTS public.custom_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.custom_users ENABLE ROW LEVEL SECURITY;

-- Create policies for custom_users
CREATE POLICY "Users can view their own data" 
ON public.custom_users 
FOR SELECT 
USING (true); -- For now, allow reading (we'll handle auth in edge function)

CREATE POLICY "Users can insert their own data" 
ON public.custom_users 
FOR INSERT 
WITH CHECK (true); -- For now, allow insertion (we'll handle auth in edge function)

-- Create function to check username availability
CREATE OR REPLACE FUNCTION public.check_username_available(p_username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  RETURN NOT EXISTS (SELECT 1 FROM public.custom_users WHERE username = p_username);
END;
$$;

-- Create function to get user by username
CREATE OR REPLACE FUNCTION public.get_user_by_username(p_username TEXT)
RETURNS TABLE(id UUID, username TEXT, password_hash TEXT, display_name TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cu.id,
    cu.username,
    cu.password_hash,
    cu.display_name
  FROM public.custom_users cu
  WHERE cu.username = p_username;
END;
$$;