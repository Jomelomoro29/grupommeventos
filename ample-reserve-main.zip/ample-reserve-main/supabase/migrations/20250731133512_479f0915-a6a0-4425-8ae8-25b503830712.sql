-- Create rooms table for meeting room management
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  capacity INTEGER NOT NULL DEFAULT 1,
  location TEXT,
  amenities TEXT[] DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;

-- Create policies for rooms access
CREATE POLICY "Anyone can view active rooms" 
ON public.rooms 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Authenticated users can create rooms" 
ON public.rooms 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Room creators can update their rooms" 
ON public.rooms 
FOR UPDATE 
USING (true);

CREATE POLICY "Room creators can delete their rooms" 
ON public.rooms 
FOR DELETE 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_rooms_updated_at
    BEFORE UPDATE ON public.rooms
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some sample rooms
INSERT INTO public.rooms (name, description, capacity, location, amenities, created_by) VALUES
('Sala de Reunião A', 'Sala principal para reuniões executivas', 12, '1º Andar', ARRAY['Wifi', 'Projetor', 'Monitor'], gen_random_uuid()),
('Sala de Reunião B', 'Sala média para reuniões de equipe', 8, '2º Andar', ARRAY['Wifi', 'Monitor'], gen_random_uuid()),
('Auditório', 'Espaço amplo para apresentações', 50, 'Térreo', ARRAY['Wifi', 'Projetor', 'Sistema de Som'], gen_random_uuid());