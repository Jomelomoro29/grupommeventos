-- Enable pgcrypto extension for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Simplify the authentication and registration functions
CREATE OR REPLACE FUNCTION public.authenticate_user(p_username TEXT, p_password TEXT)
RETURNS TABLE(user_id UUID, email TEXT, display_name TEXT, username TEXT) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  -- Find user by username - we'll validate password in the edge function for simplicity
  RETURN QUERY
  SELECT 
    p.user_id,
    au.email,
    p.display_name,
    p.username
  FROM public.profiles p
  JOIN auth.users au ON p.user_id = au.id
  WHERE p.username = p_username;
END;
$$;

-- Create a simple function to check if username exists
CREATE OR REPLACE FUNCTION public.username_exists(p_username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE username = p_username);
END;
$$;