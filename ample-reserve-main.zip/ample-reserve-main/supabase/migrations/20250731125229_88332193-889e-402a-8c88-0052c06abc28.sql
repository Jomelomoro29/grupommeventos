-- Add username field to profiles table
ALTER TABLE public.profiles 
ADD COLUMN username TEXT UNIQUE;

-- Add constraint to ensure username is not null for new users
ALTER TABLE public.profiles 
ADD CONSTRAINT username_not_empty CHECK (username IS NOT NULL AND length(trim(username)) > 0);

-- Update the handle_new_user function to create username from email
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER set search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name, avatar_url, username)
  VALUES (
    NEW.id, 
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', NEW.email),
    NEW.raw_user_meta_data ->> 'avatar_url',
    split_part(NEW.email, '@', 1) -- Use part before @ as default username
  );
  RETURN NEW;
END;
$$;