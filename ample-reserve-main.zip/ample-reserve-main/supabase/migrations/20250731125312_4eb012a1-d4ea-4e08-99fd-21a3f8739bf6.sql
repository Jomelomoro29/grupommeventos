-- First add the username column without constraints
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS username TEXT;

-- Update existing profiles to have usernames based on display_name or a default
UPDATE public.profiles 
SET username = CASE 
  WHEN display_name IS NOT NULL AND length(trim(display_name)) > 0 
  THEN lower(replace(trim(display_name), ' ', '_'))
  ELSE 'user_' || substr(user_id::text, 1, 8)
END
WHERE username IS NULL;

-- Now add the unique constraint
ALTER TABLE public.profiles 
ADD CONSTRAINT profiles_username_unique UNIQUE (username);

-- Add the not null constraint
ALTER TABLE public.profiles 
ALTER COLUMN username SET NOT NULL;