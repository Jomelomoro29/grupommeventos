-- Fix search path security issues
CREATE OR REPLACE FUNCTION public.authenticate_user(p_username TEXT, p_password TEXT)
RETURNS TABLE(user_id UUID, email TEXT, display_name TEXT, username TEXT) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  -- Find user by username and validate password
  RETURN QUERY
  SELECT 
    p.user_id,
    au.email,
    p.display_name,
    p.username
  FROM public.profiles p
  JOIN auth.users au ON p.user_id = au.id
  WHERE p.username = p_username 
    AND au.encrypted_password = crypt(p_password, au.encrypted_password);
END;
$$;

CREATE OR REPLACE FUNCTION public.register_user(p_username TEXT, p_password TEXT, p_display_name TEXT DEFAULT NULL)
RETURNS TABLE(user_id UUID, success BOOLEAN, message TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  new_user_id UUID;
  temp_email TEXT;
BEGIN
  -- Check if username already exists
  IF EXISTS (SELECT 1 FROM public.profiles WHERE username = p_username) THEN
    RETURN QUERY SELECT NULL::UUID, FALSE, 'Username already exists';
    RETURN;
  END IF;
  
  -- Create temporary email for Supabase auth
  temp_email := p_username || '@temp.local';
  
  -- Insert into auth.users (this will trigger our profile creation)
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    confirmation_token,
    created_at,
    updated_at,
    raw_app_meta_data,
    raw_user_meta_data
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    temp_email,
    crypt(p_password, gen_salt('bf')),
    now(),
    '',
    now(),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    jsonb_build_object('username', p_username, 'display_name', COALESCE(p_display_name, p_username))
  ) RETURNING id INTO new_user_id;
  
  -- Update the profile with the correct username
  UPDATE public.profiles 
  SET username = p_username,
      display_name = COALESCE(p_display_name, p_username)
  WHERE user_id = new_user_id;
  
  RETURN QUERY SELECT new_user_id, TRUE, 'User registered successfully';
END;
$$;