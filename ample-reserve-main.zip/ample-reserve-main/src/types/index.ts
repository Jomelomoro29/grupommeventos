export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
}

export interface Room {
  id: string;
  name: string;
  description?: string;
  capacity: number;
  location?: string;
  amenities?: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Reservation {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  title: string;
  description?: string;
  startDateTime: string;
  endDateTime: string;
  status: 'confirmed' | 'pending' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

export interface TimeSlot {
  time: string;
  isAvailable: boolean;
  reservation?: Reservation;
}

export interface Profile {
  id: string;
  user_id: string;
  display_name?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface AuthContextType {
  user: User | null;
  session: any | null;
  profile: Profile | null;
  login: (username: string, password: string) => Promise<void>;
  signUp: (username: string, password: string, displayName?: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}