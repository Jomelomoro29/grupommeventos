import { Room, Reservation, ApiResponse } from '@/types';

const API_BASE_URL = '/api'; // Configure this to point to your backend

const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// Room API
export const roomsApi = {
  async getAll(): Promise<Room[]> {
    const response = await fetch(`${API_BASE_URL}/rooms`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao buscar salas');
    }
    
    const data: ApiResponse<Room[]> = await response.json();
    return data.data;
  },

  async getById(id: string): Promise<Room> {
    const response = await fetch(`${API_BASE_URL}/rooms/${id}`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao buscar sala');
    }
    
    const data: ApiResponse<Room> = await response.json();
    return data.data;
  },

  async create(room: Omit<Room, 'id' | 'createdAt' | 'updatedAt'>): Promise<Room> {
    const response = await fetch(`${API_BASE_URL}/rooms`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(room),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao criar sala');
    }
    
    const data: ApiResponse<Room> = await response.json();
    return data.data;
  },

  async update(id: string, room: Partial<Room>): Promise<Room> {
    const response = await fetch(`${API_BASE_URL}/rooms/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(room),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao atualizar sala');
    }
    
    const data: ApiResponse<Room> = await response.json();
    return data.data;
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/rooms/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao deletar sala');
    }
  },
};

// Reservations API
export const reservationsApi = {
  async getByRoom(roomId: string, date?: string): Promise<Reservation[]> {
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    
    const response = await fetch(`${API_BASE_URL}/rooms/${roomId}/reservations?${params}`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao buscar reservas');
    }
    
    const data: ApiResponse<Reservation[]> = await response.json();
    return data.data;
  },

  async getByUser(): Promise<Reservation[]> {
    const response = await fetch(`${API_BASE_URL}/reservations/my`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao buscar suas reservas');
    }
    
    const data: ApiResponse<Reservation[]> = await response.json();
    return data.data;
  },

  async create(reservation: Omit<Reservation, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<Reservation> {
    const response = await fetch(`${API_BASE_URL}/reservations`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(reservation),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Erro ao criar reserva');
    }
    
    const data: ApiResponse<Reservation> = await response.json();
    return data.data;
  },

  async cancel(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/reservations/${id}/cancel`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao cancelar reserva');
    }
  },

  async checkAvailability(roomId: string, startDateTime: string, endDateTime: string): Promise<boolean> {
    const params = new URLSearchParams({
      roomId,
      startDateTime,
      endDateTime,
    });
    
    const response = await fetch(`${API_BASE_URL}/reservations/check-availability?${params}`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Erro ao verificar disponibilidade');
    }
    
    const data: ApiResponse<{ available: boolean }> = await response.json();
    return data.data.available;
  },
};