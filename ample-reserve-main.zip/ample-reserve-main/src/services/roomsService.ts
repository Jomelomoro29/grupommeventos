import { supabase } from '@/integrations/supabase/client';

export interface Room {
  id: string;
  name: string;
  description?: string;
  capacity: number;
  location?: string;
  amenities?: string[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export const roomsService = {
  async getAll(): Promise<Room[]> {
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .eq('is_active', true)
      .order('name');
    
    if (error) throw error;
    return data || [];
  },

  async create(room: {
    name: string;
    description?: string;
    capacity: number;
    location?: string;
    amenities?: string[];
  }): Promise<Room> {
    const { data, error } = await supabase
      .from('rooms')
      .insert({
        ...room,
        created_by: 'temp-user-id' // TODO: Usar real user ID quando auth estiver integrado
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, room: Partial<Room>): Promise<Room> {
    const { data, error } = await supabase
      .from('rooms')
      .update(room)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('rooms')
      .update({ is_active: false })
      .eq('id', id);
    
    if (error) throw error;
  }
};