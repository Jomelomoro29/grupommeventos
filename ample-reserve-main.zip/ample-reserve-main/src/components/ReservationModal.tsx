import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Room } from '@/types';
import { reservationsApi } from '@/services/api';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, Clock, Users, MapPin } from 'lucide-react';

interface ReservationModalProps {
  room: Room;
  date: Date;
  timeSlot: string;
  onClose: () => void;
  onSuccess: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({
  room,
  date,
  timeSlot,
  onClose,
  onSuccess,
}) => {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState(60); // 60 minutes default
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim()) return;

    setLoading(true);
    try {
      const [hours, minutes] = timeSlot.split(':').map(Number);
      const startDateTime = new Date(date);
      startDateTime.setHours(hours, minutes, 0, 0);
      
      const endDateTime = new Date(startDateTime);
      endDateTime.setMinutes(endDateTime.getMinutes() + duration);

      // Check availability before creating reservation
      const isAvailable = await reservationsApi.checkAvailability(
        room.id,
        startDateTime.toISOString(),
        endDateTime.toISOString()
      );

      if (!isAvailable) {
        toast({
          title: "Horário indisponível",
          description: "Este horário já foi reservado por outro usuário. Tente outro horário.",
          variant: "destructive",
        });
        return;
      }

      await reservationsApi.create({
        roomId: room.id,
        userId: user.id,
        userName: user.name,
        title: title.trim(),
        description: description.trim() || undefined,
        startDateTime: startDateTime.toISOString(),
        endDateTime: endDateTime.toISOString(),
      });

      toast({
        title: "Reserva criada com sucesso!",
        description: `Sua reserva para ${room.name} foi confirmada.`,
      });

      onSuccess();
    } catch (error) {
      toast({
        title: "Erro ao criar reserva",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getEndTime = () => {
    const [hours, minutes] = timeSlot.split(':').map(Number);
    const endDate = new Date(date);
    endDate.setHours(hours, minutes + duration, 0, 0);
    return format(endDate, 'HH:mm');
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Nova Reserva</DialogTitle>
          <DialogDescription>
            Preencha os dados para confirmar sua reserva
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Room Info */}
          <div className="bg-muted p-4 rounded-lg space-y-2">
            <div className="flex items-center text-sm">
              <Users className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">{room.name}</span>
            </div>
            {room.location && (
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-2" />
                <span>{room.location}</span>
              </div>
            )}
            <div className="flex items-center text-sm text-muted-foreground">
              <Calendar className="h-4 w-4 mr-2" />
              <span>{format(date, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</span>
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Clock className="h-4 w-4 mr-2" />
              <span>{timeSlot} - {getEndTime()}</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título da Reunião *</Label>
              <Input
                id="title"
                placeholder="Ex: Reunião de equipe"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Duração (minutos)</Label>
              <select
                id="duration"
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
              >
                <option value={30}>30 minutos</option>
                <option value={60}>1 hora</option>
                <option value={90}>1h 30min</option>
                <option value={120}>2 horas</option>
                <option value={180}>3 horas</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição (opcional)</Label>
              <Textarea
                id="description"
                placeholder="Detalhes adicionais sobre a reunião..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={loading}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={loading || !title.trim()}
              >
                {loading ? 'Criando...' : 'Confirmar Reserva'}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};