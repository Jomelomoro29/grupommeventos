import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Reservation } from '@/types';
import { Room } from '@/services/roomsService';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar as CalendarIcon, Clock, User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ReservationAgendaModalProps {
  room: Room;
  onClose: () => void;
}

export const ReservationAgendaModal: React.FC<ReservationAgendaModalProps> = ({
  room,
  onClose,
}) => {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadReservations();
  }, [room.id, selectedDate]);

  const loadReservations = async () => {
    try {
      const startOfDay = new Date(selectedDate);
      startOfDay.setHours(0, 0, 0, 0);
      
      const endOfDay = new Date(selectedDate);
      endOfDay.setHours(23, 59, 59, 999);

      const { data, error } = await supabase
        .from('reservations')
        .select('*')
        .eq('room_id', room.id)
        .gte('start_datetime', startOfDay.toISOString())
        .lte('start_datetime', endOfDay.toISOString())
        .order('start_datetime');

      if (error) throw error;
      
      // Transform data to match Reservation type
      const transformedData = (data || []).map(item => ({
        id: item.id,
        roomId: item.room_id,
        userId: item.user_id,
        userName: item.user_name,
        title: item.title,
        description: item.description,
        startDateTime: item.start_datetime,
        endDateTime: item.end_datetime,
        status: item.status as 'confirmed' | 'pending' | 'cancelled',
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      }));
      
      setReservations(transformedData);
    } catch (error) {
      console.error('Error loading reservations:', error);
      toast({
        title: "Erro ao carregar reservas",
        description: "Não foi possível carregar as reservas da sala.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim() || !startTime || !endTime) return;

    setLoading(true);
    try {
      const startDateTime = new Date(selectedDate);
      const [startHours, startMinutes] = startTime.split(':').map(Number);
      startDateTime.setHours(startHours, startMinutes, 0, 0);

      const endDateTime = new Date(selectedDate);
      const [endHours, endMinutes] = endTime.split(':').map(Number);
      endDateTime.setHours(endHours, endMinutes, 0, 0);

      if (endDateTime <= startDateTime) {
        toast({
          title: "Horário inválido",
          description: "A hora de fim deve ser posterior à hora de início.",
          variant: "destructive",
        });
        return;
      }

      // Check for conflicts
      const hasConflict = reservations.some(reservation => {
        const resStart = new Date(reservation.startDateTime);
        const resEnd = new Date(reservation.endDateTime);
        
        return (
          (startDateTime >= resStart && startDateTime < resEnd) ||
          (endDateTime > resStart && endDateTime <= resEnd) ||
          (startDateTime <= resStart && endDateTime >= resEnd)
        );
      });

      if (hasConflict) {
        toast({
          title: "Conflito de horário",
          description: "Já existe uma reserva neste horário.",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('reservations')
        .insert({
          room_id: room.id,
          user_id: user.id,
          user_name: user.name,
          title: title.trim(),
          start_datetime: startDateTime.toISOString(),
          end_datetime: endDateTime.toISOString(),
        });

      if (error) throw error;

      toast({
        title: "Reserva criada com sucesso!",
        description: `Sua reserva para ${room.name} foi confirmada.`,
      });

      // Reset form
      setTitle('');
      setStartTime('');
      setEndTime('');
      
      // Reload reservations
      await loadReservations();
    } catch (error) {
      toast({
        title: "Erro ao criar reserva",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>{room.name} - Agenda & Reservar</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left side - Reservation form */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Nova Reserva</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título da reunião</Label>
                <Input
                  id="title"
                  placeholder="Ex: Reunião de equipe"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Data</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? format(selectedDate, "dd/MM/yyyy", { locale: ptBR }) : <span>Selecione a data</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startTime">Hora Início</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endTime">Hora Fim</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={loading || !title.trim() || !startTime || !endTime}
              >
                {loading ? 'Criando...' : 'Reservar'}
              </Button>
            </form>
          </div>

          {/* Right side - Existing reservations */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Reservas dessa Sala</h3>
            <p className="text-sm text-muted-foreground">
              {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </p>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {reservations.length === 0 ? (
                <div className="text-center py-12 px-6">
                  <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-2xl p-8 border border-primary/10">
                    <div className="bg-gradient-to-br from-primary/10 to-primary/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                      <Clock className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      Dia livre para reuniões!
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Esta data ainda não possui reservas.<br />
                      Que tal agendar a primeira reunião?
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {reservations.map((reservation, index) => (
                    <div
                      key={reservation.id}
                      className="bg-gradient-to-r from-orange-50 to-orange-100 border border-orange-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center text-sm font-semibold text-orange-900">
                          <Clock className="h-4 w-4 mr-2 text-orange-600" />
                          {format(new Date(reservation.startDateTime), 'HH:mm')} - {format(new Date(reservation.endDateTime), 'HH:mm')}
                        </div>
                        <div className="flex items-center text-xs text-orange-700 bg-orange-200 px-2 py-1 rounded-full">
                          <User className="h-3 w-3 mr-1" />
                          {reservation.userName}
                        </div>
                      </div>
                      <h4 className="text-sm font-medium text-gray-900 mb-1">{reservation.title}</h4>
                      {reservation.description && (
                        <p className="text-xs text-gray-600 leading-relaxed">{reservation.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};