import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/layout/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Reservation, Room } from '@/types';
import { reservationsApi, roomsApi } from '@/services/api';
import { toast } from '@/hooks/use-toast';
import { Calendar, Clock, MapPin, Users, XCircle } from 'lucide-react';
import { format, isFuture, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface ReservationWithRoom extends Reservation {
  room?: Room;
}

export default function MyReservations() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<ReservationWithRoom[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [reservationsData, roomsData] = await Promise.all([
        reservationsApi.getByUser(),
        roomsApi.getAll()
      ]);

      // Merge reservations with room data
      const reservationsWithRooms = reservationsData.map(reservation => ({
        ...reservation,
        room: roomsData.find(room => room.id === reservation.roomId)
      }));

      setReservations(reservationsWithRooms);
      setRooms(roomsData);
    } catch (error) {
      toast({
        title: "Erro ao carregar reservas",
        description: "Não foi possível carregar suas reservas",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCancelReservation = async (reservationId: string) => {
    try {
      await reservationsApi.cancel(reservationId);
      toast({
        title: "Reserva cancelada",
        description: "Sua reserva foi cancelada com sucesso",
      });
      loadData(); // Reload data
    } catch (error) {
      toast({
        title: "Erro ao cancelar reserva",
        description: "Não foi possível cancelar a reserva",
        variant: "destructive",
      });
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'cancelled':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'Confirmada';
      case 'pending':
        return 'Pendente';
      case 'cancelled':
        return 'Cancelada';
      default:
        return status;
    }
  };

  const canCancelReservation = (reservation: Reservation) => {
    return reservation.status === 'confirmed' && isFuture(new Date(reservation.startDateTime));
  };

  // Group reservations by status
  const upcomingReservations = reservations.filter(r => 
    r.status === 'confirmed' && isFuture(new Date(r.startDateTime))
  );
  const pastReservations = reservations.filter(r => 
    isPast(new Date(r.endDateTime))
  );
  const cancelledReservations = reservations.filter(r => 
    r.status === 'cancelled'
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-1/3"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const ReservationCard = ({ reservation }: { reservation: ReservationWithRoom }) => (
    <Card key={reservation.id} className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{reservation.title}</CardTitle>
            <div className="flex items-center mt-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4 mr-1" />
              <span className="mr-4">{reservation.room?.name || 'Sala não encontrada'}</span>
              {reservation.room?.location && (
                <>
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{reservation.room.location}</span>
                </>
              )}
            </div>
          </div>
          <Badge variant={getStatusVariant(reservation.status)}>
            {getStatusText(reservation.status)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{format(new Date(reservation.startDateTime), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</span>
          </div>
          <div className="flex items-center text-sm">
            <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>
              {format(new Date(reservation.startDateTime), 'HH:mm')} - {format(new Date(reservation.endDateTime), 'HH:mm')}
            </span>
          </div>
          {reservation.description && (
            <p className="text-sm text-muted-foreground">{reservation.description}</p>
          )}
          
          {canCancelReservation(reservation) && (
            <div className="pt-2">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground">
                    <XCircle className="h-4 w-4 mr-2" />
                    Cancelar Reserva
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancelar Reserva</AlertDialogTitle>
                    <AlertDialogDescription>
                      Tem certeza que deseja cancelar esta reserva? Esta ação não pode ser desfeita.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Não cancelar</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={() => handleCancelReservation(reservation.id)}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Sim, cancelar
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Minhas Reservas</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie suas reservas de salas
          </p>
        </div>

        {reservations.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma reserva encontrada</h3>
              <p className="text-muted-foreground">
                Você ainda não fez nenhuma reserva.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {/* Upcoming Reservations */}
            {upcomingReservations.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4 text-foreground">Próximas Reservas</h2>
                <div className="space-y-4">
                  {upcomingReservations.map((reservation) => (
                    <ReservationCard key={reservation.id} reservation={reservation} />
                  ))}
                </div>
              </div>
            )}

            {/* Past Reservations */}
            {pastReservations.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4 text-foreground">Reservas Anteriores</h2>
                <div className="space-y-4">
                  {pastReservations.map((reservation) => (
                    <ReservationCard key={reservation.id} reservation={reservation} />
                  ))}
                </div>
              </div>
            )}

            {/* Cancelled Reservations */}
            {cancelledReservations.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4 text-foreground">Reservas Canceladas</h2>
                <div className="space-y-4">
                  {cancelledReservations.map((reservation) => (
                    <ReservationCard key={reservation.id} reservation={reservation} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}