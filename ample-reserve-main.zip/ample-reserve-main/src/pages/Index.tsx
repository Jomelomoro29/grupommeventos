import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const Index = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">ReservaSalas</CardTitle>
          <CardDescription className="text-lg">
            Sistema completo de reserva de salas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Gerencie reservas de salas de forma fácil e eficiente
          </p>
          <div className="space-y-2">
            <Button asChild className="w-full" size="lg">
              <Link to="/auth">Entrar ou Cadastrar</Link>
            </Button>
            <Button asChild variant="outline" className="w-full" size="lg">
              <Link to="/rooms">Ver Salas Disponíveis</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Index;
