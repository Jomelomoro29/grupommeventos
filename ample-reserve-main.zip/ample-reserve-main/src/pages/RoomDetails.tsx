import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/layout/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Room, Reservation, TimeSlot } from '@/types';
import { roomsApi, reservationsApi } from '@/services/api';
import { toast } from '@/hooks/use-toast';
import { ArrowLeft, Users, MapPin, Clock, Calendar as CalendarIcon } from 'lucide-react';
import { format, isSameDay, startOfDay, addMinutes, isAfter, isBefore } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ReservationModal } from '@/components/ReservationModal';

export default function RoomDetails() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [room, setRoom] = useState<Room | null>(null);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
  const [loading, setLoading] = useState(true);
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadRoomAndReservations();
    }
  }, [id, selectedDate]);

  const loadRoomAndReservations = async () => {
    if (!id) return;
    
    setLoading(true);
    try {
      const [roomData, reservationsData] = await Promise.all([
        roomsApi.getById(id),
        reservationsApi.getByRoom(id, selectedDate ? format(selectedDate, 'yyyy-MM-dd') : undefined)
      ]);
      
      setRoom(roomData);
      setReservations(reservationsData);
      generateTimeSlots(reservationsData);
    } catch (error) {
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados da sala",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const generateTimeSlots = (reservations: Reservation[]) => {
    if (!selectedDate) return;

    const slots: TimeSlot[] = [];
    const startHour = 8; // 8:00
    const endHour = 18; // 18:00
    const slotDuration = 60; // 60 minutes

    for (let hour = startHour; hour < endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00`;
      const slotStart = new Date(selectedDate);
      slotStart.setHours(hour, 0, 0, 0);
      
      const slotEnd = addMinutes(slotStart, slotDuration);

      // Check if this slot conflicts with any reservation
      const conflictingReservation = reservations.find(reservation => {
        const reservationStart = new Date(reservation.startDateTime);
        const reservationEnd = new Date(reservation.endDateTime);
        
        return (
          isSameDay(reservationStart, selectedDate) &&
          ((isAfter(slotStart, reservationStart) && isBefore(slotStart, reservationEnd)) ||
           (isAfter(slotEnd, reservationStart) && isBefore(slotEnd, reservationEnd)) ||
           (isBefore(slotStart, reservationStart) && isAfter(slotEnd, reservationEnd)) ||
           (slotStart.getTime() === reservationStart.getTime()))
        );
      });

      slots.push({
        time: timeString,
        isAvailable: !conflictingReservation || (conflictingReservation && conflictingReservation.status === 'cancelled'),
        reservation: conflictingReservation,
      });
    }

    setTimeSlots(slots);
  };

  const handleTimeSlotClick = (timeSlot: TimeSlot) => {
    if (timeSlot.isAvailable) {
      setSelectedTimeSlot(timeSlot.time);
      setShowReservationModal(true);
    }
  };

  const handleReservationSuccess = () => {
    setShowReservationModal(false);
    setSelectedTimeSlot(null);
    loadRoomAndReservations();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <div className="h-64 bg-muted rounded"></div>
              </div>
              <div className="h-96 bg-muted rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="text-center py-12">
              <h3 className="text-lg font-semibold mb-2">Sala não encontrada</h3>
              <p className="text-muted-foreground mb-4">
                A sala solicitada não foi encontrada.
              </p>
              <Link to="/rooms">
                <Button>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar para Salas
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link to="/rooms" className="inline-flex items-center text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para Salas
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Room Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">{room.name}</CardTitle>
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    Capacidade: {room.capacity} pessoas
                  </div>
                  {room.location && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {room.location}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {room.description && (
                  <p className="text-muted-foreground mb-4">{room.description}</p>
                )}
                
                {room.amenities && room.amenities.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Comodidades:</h4>
                    <div className="flex flex-wrap gap-2">
                      {room.amenities.map((amenity, index) => (
                        <Badge key={index} variant="outline">
                          {amenity}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Time Slots */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Horários - {selectedDate ? format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR }) : ''}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {timeSlots.map((slot) => (
                    <Button
                      key={slot.time}
                      variant={slot.isAvailable ? "outline" : "secondary"}
                      className={`h-12 ${
                        slot.isAvailable
                          ? "border-available text-available hover:bg-available hover:text-white"
                          : "bg-occupied/10 text-occupied border-occupied cursor-not-allowed"
                      }`}
                      onClick={() => handleTimeSlotClick(slot)}
                      disabled={!slot.isAvailable}
                    >
                      <div className="text-center">
                        <div className="font-medium">{slot.time}</div>
                        {slot.reservation && (
                          <div className="text-xs truncate">
                            {slot.reservation.userName}
                          </div>
                        )}
                      </div>
                    </Button>
                  ))}
                </div>
                
                <div className="mt-4 flex items-center gap-4 text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-available rounded mr-2"></div>
                    Disponível
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-occupied rounded mr-2"></div>
                    Ocupado
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Calendar */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CalendarIcon className="h-5 w-5 mr-2" />
                  Selecionar Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => date < startOfDay(new Date())}
                  locale={ptBR}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Reservation Modal */}
      {showReservationModal && room && selectedDate && selectedTimeSlot && (
        <ReservationModal
          room={room}
          date={selectedDate}
          timeSlot={selectedTimeSlot}
          onClose={() => {
            setShowReservationModal(false);
            setSelectedTimeSlot(null);
          }}
          onSuccess={handleReservationSuccess}
        />
      )}
    </div>
  );
}