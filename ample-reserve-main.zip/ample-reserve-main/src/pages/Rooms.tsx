import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/layout/Header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Room, roomsService } from '@/services/roomsService';
import { RoomFormModal } from '@/components/RoomFormModal';
import { ReservationAgendaModal } from '@/components/ReservationAgendaModal';
import { toast } from '@/hooks/use-toast';
import { MapPin, Users, Calendar, Wifi, Monitor, Coffee, Trash2 } from 'lucide-react';
// Force rebuild

export default function Rooms() {
  const {
    user
  } = useAuth();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  useEffect(() => {
    loadRooms();
  }, []);
  const loadRooms = async () => {
    try {
      const roomsData = await roomsService.getAll();
      setRooms(roomsData.filter(room => room.is_active));
    } catch (error) {
      toast({
        title: "Erro ao carregar salas",
        description: "Não foi possível carregar a lista de salas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateRoom = async (roomData: any) => {
    await roomsService.create(roomData);
    await loadRooms();
    toast({
      title: "Sucesso",
      description: "Sala criada com sucesso!"
    });
  };
  const handleUpdateRoom = async (roomData: any, roomId: string) => {
    await roomsService.update(roomId, roomData);
    await loadRooms();
    toast({
      title: "Sucesso",
      description: "Sala atualizada com sucesso!"
    });
  };
  const handleDeleteRoom = async (roomId: string) => {
    await roomsService.delete(roomId);
    await loadRooms();
    toast({
      title: "Sucesso",
      description: "Sala excluída com sucesso!"
    });
  };
  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi':
        return <Wifi className="h-4 w-4" />;
      case 'projetor':
      case 'monitor':
        return <Monitor className="h-4 w-4" />;
      case 'café':
      case 'coffee':
        return <Coffee className="h-4 w-4" />;
      default:
        return null;
    }
  };
  if (loading) {
    return <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>)}
          </div>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Salas Disponíveis</h1>
            <p className="text-muted-foreground mt-2">
              Escolha uma sala e faça sua reserva
            </p>
          </div>
          <RoomFormModal onSubmit={handleCreateRoom} />
        </div>

        {rooms.length === 0 ? <Card>
            <CardContent className="text-center py-12">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma sala disponível</h3>
              <p className="text-muted-foreground">
                No momento não há salas disponíveis para reserva.
              </p>
            </CardContent>
          </Card> : <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rooms.map(room => <Card key={room.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      {room.name}
                      
                    </CardTitle>
                    <div className="flex items-center space-x-1">
                      <RoomFormModal room={room} onSubmit={data => handleUpdateRoom(data, room.id)} />
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Excluir Sala</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja excluir a sala "{room.name}"? Esta ação não pode ser desfeita.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteRoom(room.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                              Excluir
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  {room.location && <CardDescription className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {room.location}
                    </CardDescription>}
                </CardHeader>
                <CardContent>
                  {room.description && <p className="text-sm text-muted-foreground mb-4">
                      {room.description}
                    </p>}
                  
                  {room.amenities && room.amenities.length > 0 && <div className="mb-4">
                      <p className="text-sm font-medium mb-2">Comodidades:</p>
                      <div className="flex flex-wrap gap-2">
                        {room.amenities.map((amenity, index) => <Badge key={index} variant="outline" className="text-xs">
                            {getAmenityIcon(amenity)}
                            <span className="ml-1">{amenity}</span>
                          </Badge>)}
                      </div>
                    </div>}

                  <Button className="w-full" onClick={() => setSelectedRoom(room)}>
                    <Calendar className="h-4 w-4 mr-2" />
                    Ver Agenda & Reservar
                  </Button>
                </CardContent>
              </Card>)}
          </div>}
      </div>

      {/* Reservation Agenda Modal */}
      {selectedRoom && <ReservationAgendaModal room={selectedRoom} onClose={() => setSelectedRoom(null)} />}
    </div>;
}