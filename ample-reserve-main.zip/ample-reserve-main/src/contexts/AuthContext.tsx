import React, { createContext, useContext, useState, useEffect } from 'react';
import { User as SupabaseUser, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { User, AuthContextType, Profile } from '@/types';
import { toast } from '@/hooks/use-toast';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session token
    const checkSession = () => {
      const sessionToken = localStorage.getItem('sessionToken');
      if (sessionToken) {
        try {
          const sessionData = JSON.parse(atob(sessionToken));
          // Check if token is still valid (less than 24 hours old)
          if (Date.now() - sessionData.timestamp < 24 * 60 * 60 * 1000) {
            const userData: User = {
              id: sessionData.userId,
              email: sessionData.email || '',
              name: sessionData.displayName || sessionData.username,
              role: 'user'
            };
            setUser(userData);
          } else {
            // Token expired
            localStorage.removeItem('sessionToken');
          }
        } catch (error) {
          console.error('Error parsing session token:', error);
          localStorage.removeItem('sessionToken');
        }
      }
      setIsLoading(false);
    };

    checkSession();
  }, []);

  const login = async (username: string, password: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('username-auth', {
        body: {
          username,
          password,
          action: 'login'
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!data.success) {
        throw new Error(data.error || 'Login failed');
      }

      // Set the user data
      setUser(data.user);
      
      // Store session token in localStorage
      localStorage.setItem('sessionToken', data.sessionToken);

      toast({
        title: "Login realizado com sucesso!",
        description: `Bem-vindo(a), ${data.user.name}!`,
      });
    } catch (error) {
      toast({
        title: "Erro no login",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signUp = async (username: string, password: string, displayName?: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('username-auth', {
        body: {
          username,
          password,
          action: 'register',
          displayName
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!data.success) {
        throw new Error(data.error || 'Registration failed');
      }

      toast({
        title: "Cadastro realizado!",
        description: "Agora você pode fazer login com seu usuário e senha.",
      });
    } catch (error) {
      toast({
        title: "Erro no cadastro",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/rooms`
        }
      });

      if (error) {
        throw new Error(error.message);
      }
    } catch (error) {
      toast({
        title: "Erro no login com Google",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      // Clear user data and session
      setUser(null);
      setSession(null);
      setProfile(null);
      localStorage.removeItem('sessionToken');

      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro no logout",
        description: error instanceof Error ? error.message : "Erro inesperado",
        variant: "destructive",
      });
    }
  };

  const value: AuthContextType = {
    user,
    session,
    profile,
    login,
    signUp,
    signInWithGoogle,
    logout,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};